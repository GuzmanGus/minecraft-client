#define ABOUT 0 //[0]

#define TONEMAP
#define RAIN
#define SHADOWS
#define SKY
#define FOG
#define WATER
#define UNDERWATER
#define CLOUDS 0 //[0 1 2]
#define LIGHT
#define GLOWING_ORES
#define WAVE

#define CHROM_ABERRATION    10     // Chromatic Aberration     [0 10]
#define CHROM_STRENGTH 0.5     // Chromatic Aberration Strength [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define CA_COLOR 0     // Chromatic Aberration Color [0 1 2 3]

#define SATURATION 0.3           // Saturation               [-1.0 -0.9 -0.8 -0.7 -0.6 -0.5 -0.4 -0.3 -0.2 -0.1 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define WAVING_HAND
#define YAXIS 0.02 //[0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.10 0.11 0.12 0.13 0.14 0.15 0.16 0.17 0.18 0.19 0.20 0.21 0.22 0.23 0.24 0.25 0.26 0.27 0.28 0.29 0.30]
#define XAXIS 0.02 //[0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.10 0.11 0.12 0.13 0.14 0.15 0.16 0.17 0.18 0.19 0.20 0.21 0.22 0.23 0.24 0.25 0.26 0.27 0.28 0.29 0.30]
#define FRAMETIME1 1.5 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0]
#define FRAMETIME2 2.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0]

const float sunPathRotation=25.0;//[0.0 25.0 50.0 75.0 90.0]


#define SCR 0.35 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SCG 0.65 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00] 
#define SCB 0.95 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define SCNR 0.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SCNG 0.05 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00] 
#define SCNB 0.15 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define WCR 0.35 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define WCG 0.70 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00] 
#define WCB 0.80 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define WCNR 0.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define WCNG 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00] 
#define WCNB 0.15 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define FCR 0.55 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define FCG 0.70 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00] 
#define FCB 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define FCNR 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define FCNG 0.10 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00] 
#define FCNB 0.15 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#define daySkyColor vec3(SCR,SCG,SCB)
#define nightSkyColor vec3(SCNR, SCNG, SCNB)
#define duskSkyColor vec3(1.2,.3,.5)
#define rainSkyColor vec3(.12,.12,.12)
#define underWaterSkyColor vec3(.2,.2,1.)

#define dayWaterColor vec3(WCR,WCG,WCB)
#define nightWaterColor vec3(WCNR,WCNG,WCNB)
#define duskWaterColor vec3(1.2,.3,.5)
#define rainWaterColor vec3(.12,.12,.12)

#define dayCloudColor vec3(1.)
#define nightCloudColor vec3(.0,.13,.25)
#define duskCloudColor vec3(2.,1.,.8)
#define rainCloudColor vec3(.2,.2,.2)

#define dayFogColor vec3(FCR,FCG,FCB)
#define nightFogColor vec3(FCNR,FCNG,FCNB)
#define duskFogColor vec3(1.,.34,.0)
#define rainFogColor vec3(.15,.15,.15)
#define underwaterFogColor vec3(2.,8.,10.)

#define dayColor vec3(1.32,1.32,1.32)
#define nightColor vec3(.9,.9,1.)
#define duskColor vec3(8.,2.,.8)
#define rainColor vec3(.6,.7,1.)
#define underWaterColor vec3(.6,.6,20.)
#define caveColor vec3(1.2,1.1,1.)

#define lightColor vec3(2.,.7,.0)

#define saturate(x) clamp(x,0.,1.)
#define toneMap(b,c) tonemapFilmic(b*(b*c))

#define pow5(x) x*x*x*x*x