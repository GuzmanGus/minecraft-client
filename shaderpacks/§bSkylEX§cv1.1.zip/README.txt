

///// Credits //////

- MLGImposter - Me, that developed this pack
- DrDesten - Chromatic Aberration modified from his shaderpack
- Yamarin - Developer of the base shaderpack (Skylec)

///// Agreement ////

- You can redistribute Skylex ONLY by using the original link on curseforge or the website
- You cannot use code from Skylex without my permission
- You cannot publish in the web edits of Skylex, use Skylec as a base instead
- You cannot Skylex as your own work
- You can make videos about Skylex if the rules above are followed

//// Changelog //////

- v1.1 -

Fixed some bugs related to sun/moon reflections
Improved Water
Modifies to the default settings
Added waving hand
Other improvements